import { Theme, ThemeOptions } from '@mui/material';
declare const init: (nameTheme: string, updateTheme: ThemeOptions) => Theme;
export { init as initTheme };
export type { Theme };
