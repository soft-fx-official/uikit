/// <reference types="react" />
import '@fontsource/inter/300.css';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import '@fontsource/inter/700.css';
declare const App: () => JSX.Element;
export default App;
       