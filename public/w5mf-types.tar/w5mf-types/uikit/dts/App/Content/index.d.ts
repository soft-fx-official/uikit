/// <reference types="react" />
declare const Content: () => JSX.Element;
export { Content };
