import React from 'react';
interface IButtonCardContainer {
    children: any;
    sx?: any;
}
declare const ButtonCardContainer: React.FC<IButtonCardContainer>;
export { ButtonCardContainer };
